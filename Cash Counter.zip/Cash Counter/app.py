# Name: Cash Counter
# Author: Tassadduk Bappi
# Date: 20/09/2022

from flask import render_template, Flask, request, session
import webbrowser
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.pool import NullPool

# import database classes from model.py
from model import OnlineUser, CashRecord, TempInput

# register the app under the database
app = Flask(__name__)
db = SQLAlchemy(app)
app.secret_key = "123456"
app.config['SQLALCHEMY_DATABASE_URI'] = "postgres://nxklrrdlrjzgnz:5d89439934d129ccdf3f4145e0646836cfcc16b4a87bd5ae87e5765e9399e57c@ec2-54-228-218-84.eu-west-1.compute.amazonaws.com:5432/d165n8ng77osk7"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'poolclass': NullPool,
}
engine_container = db.get_engine(app)

# for closing idle transactions in postgre database
def cleanup(session):
    """
    This method cleans up the session object and also closes the connection pool using the dispose method.
    """
    session.close()
    engine_container.dispose()

@app.route('/')
def index():
    print("Hello!")
    data = "Welcome to Cash Counter!"
    
    return render_template('welcome.html', data=data)


@app.route('/login', methods=['POST', 'GET'])
def cashCounter():
    if request.method == 'POST':

        counterUser = request.form.get('counterUser').lower()
        user = OnlineUser.query.filter_by(counterUser=counterUser).first()
        if user:
            print("user already registered under this counter!")
        else:
            new_user = OnlineUser(counterUser=counterUser)
            db.session.add(new_user)
            db.session.commit()

        cleanup(db.session)

        return render_template('mainView.html', counterUser=counterUser)

# Add/Scan items from shopping cart. After calculating corresponding taxes, stores the value in database and displays current items including taxes
@app.route('/addItem', methods=['POST', 'GET'])
def addItem():
    if request.method == 'POST':

        catagory = request.form.get('catagory')
        productName = request.form.get('proName')
        productPrice = request.form.get('proPrice')
        currentUser = request.form.get('currentUser')

        if catagory == 'Imported Food':
            priceWithoutTax = float(productPrice)
            priceTax = priceWithoutTax * 0.05
            includingTax = "{:.2f}".format(priceWithoutTax + priceTax)
        elif catagory == 'Imported Cosmetics':
            priceWithoutTax = float(productPrice)
            priceTax = priceWithoutTax * 0.15
            includingTax = "{:.2f}".format(priceWithoutTax + priceTax)
        elif catagory == 'Cosmetics' or catagory == 'Entertainment':
            priceWithoutTax = float(productPrice)
            priceTax = priceWithoutTax * 0.1
            includingTax = "{:.2f}".format(priceWithoutTax + priceTax)
        else:
            includingTax = productPrice
            priceTax = 0

        addToCart = TempInput(counterUser=currentUser, catagory=catagory, productName=productName, productPrice=includingTax, taxes=priceTax)
        db.session.add(addToCart)
        db.session.commit()
        
        itemInCart = TempInput.query.filter_by(counterUser=currentUser).all()

        cleanup(db.session)

        return render_template('mainView.html', counterUser=currentUser, itemList=itemInCart)

# get all items under current user and then prints the bill. it also clears the items from the list to start new Add/Scan 
@app.route('/printList', methods=['POST', 'GET'])
def printList():
    if request.method == 'POST':

        print("inside print function!")
        totallPrice = []
        taxes = []
        
        currentUser = request.form.get('currentUser')

        getItems = TempInput.query.filter_by(counterUser=currentUser).all()
        for price in getItems:
            totallPrice.append(price.productPrice)
            taxes.append(price.taxes)

        salesTaxes = "{:.2f}".format(sum(taxes))
        grandTotal = "{:.2f}".format(sum(totallPrice))

        db.session.query(TempInput).filter_by(counterUser=currentUser).delete()
        db.session.commit()

        cleanup(db.session)

        return render_template('mainView.html',counterUser=currentUser, Bill=getItems, SalesTaxes=salesTaxes, GrandTotal=grandTotal)

@app.route('/logout', methods=['POST', 'GET'])
def logout():
    if request.method == 'POST':

        print("inside logout function!")
        currentUser = request.form.get('currentUser')

        db.session.query(OnlineUser).filter_by(counterUser=currentUser).delete()
        db.session.commit()
        session.clear()

        cleanup(db.session)

        data = "Welcome to Cash Counter!"
        
        return render_template('welcome.html', data=data)

if __name__=="__main__":

    webbrowser.open('http://127.0.0.1:5000')
    app.run(use_reloader=False, debug=True)
